export type ZodErrorType = { [key: string]: string };
