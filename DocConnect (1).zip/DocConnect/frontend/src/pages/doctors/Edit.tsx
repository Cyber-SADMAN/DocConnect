const Edit = () => {
    return (
        <div>
            <h1>Edit doctor info</h1>
        </div>
    );
};

export default Edit;
