const List = () => {
    return (
        <div>
            <h1>Doctors list for amdin</h1>
        </div>
    );
};

export default List;
